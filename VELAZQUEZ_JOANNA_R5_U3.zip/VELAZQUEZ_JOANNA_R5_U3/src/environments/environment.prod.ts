export const environment = {
  production: true,
  firebase :  {
    apiKey: "AIzaSyA_245agiXjydcl-uXJpTuqRXUq_lfEcU0",
    authDomain: "ionic-noticias-b9eb4.firebaseapp.com",
    projectId: "ionic-noticias-b9eb4",
    storageBucket: "ionic-noticias-b9eb4.appspot.com",
    messagingSenderId: "752848092212",
    appId: "1:752848092212:web:c579f74cd4a0a7d5299e61",
    measurementId: "G-6P16SL9GSK"
  }
};
