export class NoticiaModel {
  id!: string;
  title!: string;
  description!: string;
  date!: string;
}