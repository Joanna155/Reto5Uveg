import { Injectable } from "@angular/core";
import { collectionData, Firestore } from "@angular/fire/firestore";

import { map } from "rxjs";
import { NoticiaModel } from "../models/noticia.model";
import { getFirestore, collection, doc, setDoc, deleteDoc } from "firebase/firestore";


@Injectable({
  providedIn: 'root'
})
export class FirestoreService {

  constructor(private firestore: Firestore) { }

  createNoticia(data: NoticiaModel): Promise<void> {
    const document = doc(collection(getFirestore(), 'noticias'));
    return setDoc(document, data);
  }

  getNoticia() {
    const query = collection(getFirestore(), 'noticias')
    return collectionData(query, { idField: 'id' }).pipe(map(noticias => noticias as NoticiaModel[]));
  }

  deleteNoticia(id: string): Promise<void> {
    const document = doc(collection(getFirestore(), 'noticias'), id);
    return deleteDoc(document);
  }
}
