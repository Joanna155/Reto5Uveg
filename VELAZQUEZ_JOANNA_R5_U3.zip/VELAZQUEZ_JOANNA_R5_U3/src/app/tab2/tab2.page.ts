import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FirestoreService } from '../services/firestore.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  ionicForm: FormGroup;
  date: Date = new Date();
  isOpen = false;
  firestoreService: FirestoreService;
  router: Router;

  constructor(_form: FormBuilder, _firestoreService: FirestoreService, _router: Router) {
    this.ionicForm = _form.group({
      title: ['', [Validators.required, Validators.minLength(5)]],
      date: ['', [Validators.required]],
      description: ['', [Validators.required, Validators.minLength(5)]],
    });
    this.firestoreService = _firestoreService;
    this.router = _router;
  }

  async onSubmit() {
    await this.firestoreService.createNoticia(this.ionicForm.value);
    this.ionicForm.reset();
    this.router.navigate(['tabs/noticias'])
  }
}
