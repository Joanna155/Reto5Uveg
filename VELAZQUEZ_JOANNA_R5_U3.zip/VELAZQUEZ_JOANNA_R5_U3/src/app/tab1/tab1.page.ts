import { Component } from '@angular/core';
import { FirestoreService } from '../services/firestore.service';
import { NoticiaModel } from '../models/noticia.model';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  firestoreService: FirestoreService;
  noticias: NoticiaModel[] = [];

  constructor(_firestoreService: FirestoreService) {
    this.firestoreService = _firestoreService;
    this.loadNews();
  }

  loadNews() {
    this.firestoreService.getNoticia().subscribe((_noticias) => {
      this.noticias = _noticias;
      console.log(this.noticias);
    });
  }

  async deleteNews(id: string) {
    await this.firestoreService.deleteNoticia(id);
  }
}
